const { google } = require('googleapis');
require('dotenv').config();

const credentials = JSON.parse(process.env.CREDENTIALS);
const calendar = google.calendar({ version: 'v3' });

// Google calendar API 
const SCOPES = 'https://www.googleapis.com/auth/calendar.readonly';

const auth = new google.auth.JWT(
    credentials.client_email,
    null,
    credentials.private_key,
    SCOPES
);

// Fetch busy intervals for a given calendar within a specified time range
const fetchBusyIntervals = async (calendarId, startDateTime, endDateTime) => {
    try {
        const response = await calendar.freebusy.query({
            auth: auth,
            requestBody: {
                timeMin: startDateTime.toISOString(),
                timeMax: endDateTime.toISOString(),
                items: [{ id: calendarId }]
            }
        });

        // Extracting the busy intervals from the response
        const busyIntervals = response.data.calendars[calendarId].busy;
        return busyIntervals;

    } catch (error) {
        console.error('Error fetching busy intervals:', error.message);
        return [];
    }
};

// Main function to get busy intervals
const getBusyIntervals = async (calendarId, startDateTime, endDateTime) => {
    const busyIntervals = await fetchBusyIntervals(calendarId, startDateTime, endDateTime);
    return busyIntervals;
};

//calendarId
const CalendarId = '3f5bd907c414d728c91f617001acae2413e90100281a336a63d10cbc2bb619d8@group.calendar.google.com';

//Input StartDate
const StartDate = new Date('2024-07-09');

//Input EndDate
const EndDate = new Date('2024-07-18');

getBusyIntervals(CalendarId, StartDate, EndDate)
    .then((busyIntervals) => {
        console.log('Busy Intervals:', busyIntervals);
    })
    .catch((error) => {
        console.error('Error:', error.message);
    });
