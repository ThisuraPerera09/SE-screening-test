

function Sales(sales) {
    //create a new array to store sales with Total value
    const salesTotal = [];
      for (let item of sales) {
       const newSale = {
           amount: item.amount,
           quantity: item.quantity,
           total: item.amount * item.quantity
       };
       salesTotal.push(newSale);
   }

   // Sort the Array to Decs Order
    salesTotal.sort((a, b) => b.total - a.total);

   return salesTotal;
}

const sales = [
   {quantity:60 , amount:5000},
   {quantity:5 , amount:1000},
   {quantity:10 , amount:2000}
   ];

console.log(sales);

const orderedSales = Sales(sales);

console.log(orderedSales);