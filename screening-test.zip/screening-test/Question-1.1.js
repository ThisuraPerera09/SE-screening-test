Date.prototype.daysTo = function(date) {

    //Get the difference in mili-seconds
    const timeDifference = date.getTime() - this.getTime();
    
    // Convert the difference to days
    const Difference = Math.round(timeDifference/(60 * 60 * 24 * 1000));

    return Difference;
}

//Input day1,day2 values
const d1 = new Date('2024-04-09');
const d2 = new Date('2024-05-10');
console.log(d1.daysTo(d2));