function objectProjection(src, proto) {
    let projectedObj = {};


    for (let key in proto) {
        if (src.hasOwnProperty(key)) {

            //check proto has nested objects
            if ( proto[key] != null) {
                projectedObj[key] = {};

                //iterate over nested keys
                for (let nestedKey in proto[key]) {
                    if (src[key].hasOwnProperty(nestedKey)) {
                        projectedObj[key][nestedKey] = src[key][nestedKey];
                    }
                }
            } 
            //for normal objects
            else {
                projectedObj[key] = src[key];
            }
        }
    }

    return projectedObj;
}

//normal object

console.log("Normal objects");
console.log("-------------------------------------------------------------");

const src = {
    name: "Thisura",
    age: 25,
    city: "Kottawa",
    email: "thisuraperera09@gmail.com"
};

let proto = {
    name: "",
    age: 0,
    country: ""
};

console.log("src =", src);
console.log("proto =", proto);

const projectedObj = objectProjection(src, proto);
console.log("res =",projectedObj);


//nested object

console.log("Nested objects");
console.log("-------------------------------------------------------------");

const nestedSrc = {
    person: {
        name: "Thisura",
        age: 30,
        address: {
            city: "Kottawa",
            lane: "3 rd lane"
        }
    },
    school: {
        name: "Royal College",
        location: {
            city: "Colombo 07",
            lane: "Rajakeeya Mawatha"
        }
    }
};

const nestedProto = {
    person: {
        name: "",
        address: {
            city: ""
        }
    },
    school: {
        name: ""
    }
};

console.log("src =", nestedSrc);
console.log("proto =", nestedProto);

let nestedProjectedObj = objectProjection(nestedSrc, nestedProto); 
console.log("res = ",nestedProjectedObj);
